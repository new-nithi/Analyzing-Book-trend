from pathlib import Path

def main():
    # TODO: add your pipeline steps here (load data, process, save figures)
    print("Repo scaffold created. Plug your steps in src/main.py")

if __name__ == "__main__":
    main()
