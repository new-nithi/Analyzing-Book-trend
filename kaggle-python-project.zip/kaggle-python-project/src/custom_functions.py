# Extracted helper functions/classes from the notebook.
# (No standalone function/class definitions found.)
