# Data Folder
Place datasets here. If data is from Kaggle, prefer to document how to download with Kaggle API instead of committing raw files.
